-- phpMyAdmin SQL Dump
-- version 3.5.1
-- http://www.phpmyadmin.net
--
-- Host: localhost
-- Generation Time: Oct 16, 2014 at 05:28 PM
-- Server version: 5.1.36-community-log
-- PHP Version: 5.3.0

SET SQL_MODE="NO_AUTO_VALUE_ON_ZERO";
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8 */;

--
-- Database: `ron`
--

-- --------------------------------------------------------

--
-- Table structure for table `usermetas`
--

CREATE TABLE IF NOT EXISTS `usermetas` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `user_id` int(11) NOT NULL,
  `firstname` varchar(60) NOT NULL,
  `middlename` varchar(60) DEFAULT NULL,
  `lastname` varchar(60) DEFAULT NULL,
  `address_lineone` varchar(60) DEFAULT NULL,
  `address_linetwo` varchar(60) DEFAULT NULL,
  `city` varchar(20) DEFAULT NULL,
  `state` varchar(20) DEFAULT NULL,
  `zip` int(10) DEFAULT NULL,
  `email_id` varchar(60) DEFAULT NULL,
  `contact_number` varchar(15) DEFAULT NULL,
  `mobile_number` varchar(15) DEFAULT NULL,
  `dob` date DEFAULT NULL,
  `gender` tinyint(4) NOT NULL DEFAULT '0' COMMENT '0=Not to Specify,1=Male,2=Female',
  `profile_image` varchar(80) DEFAULT NULL,
  `social_fb` varchar(160) DEFAULT NULL,
  `social_twitter` varchar(160) DEFAULT NULL,
  `status` tinyint(4) NOT NULL DEFAULT '1' COMMENT '0=Inactive,1=Active',
  `flag` tinyint(4) NOT NULL DEFAULT '1' COMMENT '0=Is deleted,1=Working',
  `createdby` int(11) DEFAULT NULL,
  `modifiedby` int(11) DEFAULT NULL,
  `created` datetime NOT NULL,
  `modified` datetime NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=MyISAM  DEFAULT CHARSET=latin1 AUTO_INCREMENT=3 ;

--
-- Dumping data for table `usermetas`
--

INSERT INTO `usermetas` (`id`, `user_id`, `firstname`, `middlename`, `lastname`, `address_lineone`, `address_linetwo`, `city`, `state`, `zip`, `email_id`, `contact_number`, `mobile_number`, `dob`, `gender`, `profile_image`, `social_fb`, `social_twitter`, `status`, `flag`, `createdby`, `modifiedby`, `created`, `modified`) VALUES
(1, 1, 'Anuj', 'Yogeshkumar', 'Jaha', 'E-12 Susmita Flat', 'Vasna', 'Ahmedabad', 'Gujarat', 38001, 'er.anujjaha@gmail.com', '8000060541', NULL, '2014-08-09', 0, NULL, NULL, NULL, 1, 1, NULL, NULL, '2014-09-28 03:00:00', '2014-09-28 04:10:13'),
(2, 3, 'Test', 'Company', 'Test Last', 'D1 , BD Tower Vastrapur', 'Ahmedabad', 'Ahmedabad', 'Gujartat', 380001, 'er.khushbum@gmail.com', '9510864443', NULL, '2014-09-16', 0, NULL, NULL, NULL, 1, 1, NULL, NULL, '2014-09-29 04:14:17', '2014-09-29 05:13:14');

-- --------------------------------------------------------

--
-- Table structure for table `users`
--

CREATE TABLE IF NOT EXISTS `users` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `username` varchar(60) NOT NULL,
  `password` varchar(100) NOT NULL,
  `role` tinyint(4) NOT NULL COMMENT '0=admin,1=company,2=companyadmin,3=employee,4=vendor,5=client',
  `status` tinyint(4) DEFAULT '1' COMMENT '0=inactive,1=active',
  `flag` tinyint(4) NOT NULL DEFAULT '0' COMMENT '0=is Deleted ,1=is Working',
  `createdby` int(11) DEFAULT NULL,
  `modifiedby` int(11) DEFAULT NULL,
  `created` datetime NOT NULL,
  `modified` datetime NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=MyISAM  DEFAULT CHARSET=latin1 AUTO_INCREMENT=4 ;

--
-- Dumping data for table `users`
--

INSERT INTO `users` (`id`, `username`, `password`, `role`, `status`, `flag`, `createdby`, `modifiedby`, `created`, `modified`) VALUES
(1, 'anuj', '$2a$10$O4hOmE3Xcezejziwc/K.v.0AZ0rYaaq/qMK4nw4BQhLg9D1sw9QiK', 0, 1, 0, 0, 0, '2014-09-28 05:09:12', '2014-09-28 06:17:13'),
(3, 'test', '$2a$10$a0Gl.OY9T4.sqzUSwDr6gemx094iv2QCdL4ObptoV4KBF/YQFTQMS', 1, 1, 0, NULL, NULL, '2014-09-29 18:05:20', '2014-09-29 18:05:20');

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
